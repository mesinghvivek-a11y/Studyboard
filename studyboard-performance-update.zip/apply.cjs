const fs=require('node:fs'),path=require('node:path');

function updateStudyBoard(original){
  let html=original;
  function replace(old,next){
    const i=html.indexOf(old);
    if(i<0 || html.indexOf(old,i+old.length)>=0) throw Error('Source changed near '+old.slice(0,74)+'. No file has been written.');
    html=html.slice(0,i)+next.replace(/[ \t]+(?=\n)/g,'')+html.slice(i+old.length);
  }
  function section(first,last,next){
    const start=html.indexOf(first), end=html.indexOf(last,start+first.length);
    if(start<0 || end<0) throw Error('Source changed near '+first+'. No file has been written.');
    replace(html.slice(start,end),next);
  }
  function before(anchor,code){replace(anchor,code+'\n'+anchor);}
  // Keep the on-device timer model alive regardless of which tab is visible.
  const routes={renderSessions:'timer',renderGoalCard:'timer',renderDayScroller:'today',renderWeeklyGoalsList:'week',renderStudyChart:'history',renderSubjectDonut:'history'};
  for(const [fn,route] of Object.entries(routes)) replace(`  function ${fn}(){`,`  function ${fn}(){\n    if(currentScreen!=='${route}') return;`);
  replace('    const sharedTasks = await loadSharedTasks(dateKey);\n\n      html', '    const sharedTasks = sharedView.rows;\n\n      html');
  const taskScope=`
  const sharedView = {date:null, rows:[], unsubscribe:null};
  const threadViews = new Map();
  const historyBadges = new Map();
  function syncSharedView(){
    const date = me && currentScreen==='today' && !document.hidden ? fmtDate(selectedDate) : null;
    if(date===sharedView.date) return;
    sharedView.unsubscribe?.();
    sharedView.date = date;
    sharedView.rows = [];
    sharedView.unsubscribe = null;
    syncThreadViews([]);
    if(!date) return;
    sharedView.unsubscribe = onSnapshot(doc(db,'sharedTasks',date), snap=>{
      if(sharedView.date!==date) return;
      sharedView.rows = snap.exists() ? snap.data().value || [] : [];
      renderTaskList();
    }, err=>console.warn('Shared tasks unavailable',err));
  }
  function paintUnread(btn,items){
    const unread = !!me && items.some(c=>c.by!==me.id && c.ts>(myReads[btn.dataset.cid]||0));
    btn.classList.toggle('has-unread',unread);
    btn.closest('.task-menu-wrap')?.querySelector('.task-menu-btn')?.classList.toggle('has-unread',unread);
  }
  function syncThreadViews(buttons){
    const wanted = new Map();
    for(const btn of buttons){
      const id = btn.dataset.cid;
      if(!wanted.has(id)) wanted.set(id,[]);
      wanted.get(id).push(btn);
    }
    for(const [id,entry] of threadViews){
      if(!wanted.has(id)){ threadViews.delete(id); entry.stop(); }
    }
    for(const [id,nodes] of wanted){
      let entry = threadViews.get(id);
      if(!entry){
        entry = {nodes,items:[],stop:()=>{}};
        threadViews.set(id,entry);
        entry.stop = onSnapshot(doc(db,'comments',id), snap=>{
          if(threadViews.get(id)!==entry) return;
          entry.items = snap.exists() ? snap.data().items || [] : [];
          entry.nodes.forEach(node=>paintUnread(node,entry.items));
        },err=>console.warn('Comment counts unavailable',err));
      }
      entry.nodes = nodes;
      nodes.forEach(node=>paintUnread(node,entry.items));
    }
  }
  document.addEventListener('visibilitychange',()=>{
    if(!me || !stateReadyToPersist) return;
    syncSharedView();
    if(!document.hidden && currentScreen==='today') renderTaskList();
  });
  `;
  before('  async function renderTaskList(){',taskScope);
  replace('  async function renderTaskList(){','  async function renderTaskList(){\n    if(currentScreen!==\'today\' || document.hidden || !me) return;\n    syncSharedView();');
  section('  async function checkUnread(btn){','  async function openCommentsModal(',`
  function attachCommentButtons(el,live=false){
    const nodes = Array.from(el.querySelectorAll('.cmt-btn'));
    for(const btn of nodes){
      const id = btn.dataset.cid;
      if(btn.dataset.commentWired) continue;
      btn.dataset.commentWired = '1';
      btn.addEventListener('click',()=>openCommentsModal(id,btn.dataset.title,btn));
      if(!live){
        if(!historyBadges.has(id)) historyBadges.set(id,loadComments(id));
        historyBadges.get(id).then(items=>paintUnread(btn,items));
      }
    }
    if(live) syncThreadViews(nodes);
  }
`);
  section('    attachCommentButtons(el);\n    // mirror','  // ---------- WEEK SCREEN','    attachCommentButtons(el,true);\n  }\n\n');
  replace("    myReads[cid] = Date.now();","    myReads[cid] = Date.now();\n    historyBadges.delete(cid);\n    threadViews.get(cid)?.nodes.forEach(btn=>paintUnread(btn,[]));");
  replace("      const linkedRows = dates.map(dateKey=>{","      const linkedRows = !isOpen ? '' : dates.map(dateKey=>{");
  before("    if(!ringLenPickerBuilt){ ringLenPickerBuilt = true; buildRingLenPicker(); }","    syncSharedView();");
  replace("    renderSubjectOptions(document.getElementById('timerSubject'), document.getElementById('timerSubject').value);\n    renderSessions();","    if(currentScreen==='timer') renderSubjectOptions(document.getElementById('timerSubject'), document.getElementById('timerSubject').value);\n    renderSessions();");
  const pctFn=`
  function taskPercent(task,dateKey,includeRunning){
    const minutes = (state.sessions[dateKey] || []).reduce((sum,s)=>sum+(s.linkedTaskId===task.id ? s.duration||0 : 0),0);
    const active = includeRunning && timerRunning && linkedTaskId===task.id ? elapsedMs/60000 : 0;
    return Math.min(100,Math.round(100*(minutes+active)/(task.duration||30)));
  }
  function completeIfDue(task,dateKey,pct){
    const key = dateKey+'|'+task.id;
    if(pct<100 || state.completion[key]==='done' || state.completion[key]==='missed') return false;
    state.completion[key] = 'done';
    saveState();
    localNotify('taskComplete','Task completed 🎉',task.label || subjectNameIn(task.subject,state));
    return true;
  }
  function updateLinkedProgress(){
    const task = linkedTaskId && state.targets[linkedTaskId];
    if(!task) return;
    const dateKey = fmtDate(new Date(sessionStartClock || Date.now()));
    const pct = taskPercent(task,dateKey,true);
    const changed = completeIfDue(task,dateKey,pct);
    if(currentScreen!=='today' || document.hidden || fmtDate(selectedDate)!==dateKey) return;
    if(changed){ renderTaskList(); return; }
    if(state.completion[dateKey+'|'+task.id]) return;
    const row = Array.from(document.querySelectorAll('[data-progress-task]')).find(el=>el.dataset.progressTask===task.id);
    if(row){
      row.querySelector('.progress-fill').style.width = pct+'%';
      row.querySelector('.name-pct').textContent = pct ? pct+'%' : '';
    }
  }
  function reconcileLoggedTasks(){
    const now = new Date(), date = fmtDate(now);
    if(!(state.sessions[date] || []).some(s=>s.linkedTaskId)) return;
    for(const task of blocksForDateIn(state,now)) completeIfDue(task,date,taskPercent(task,date,true));
  }
`;
  before('  function startLiveUiTicker(){',pctFn);
  section('          let status = state.completion[compKey];','          const subjColor = ',`          const pct = isToday && state.completion[compKey]!=='missed' ? taskPercent(b,dateKey,true) : 0;
          if(isToday) completeIfDue(b,dateKey,pct);
          const status = state.completion[compKey];
          const checkInner = status==='done' ? '✓' : status==='missed' ? '✕' : status==='moved' ? '➡️' : '';
`);
  replace('            <div class="task-card ${status===\'done\'?', '            <div data-progress-task="${escapeHtml(b.id)}" class="task-card ${status===\'done\'?');
  replace('${displayPct>0 ? `<div class="progress-fill" style="width:${displayPct}%; background:linear-gradient(90deg, ${subjColor}4d, ${subjColor}b3);"></div>` : \'\'}','<div class="progress-fill" style="width:${displayPct}%; background:linear-gradient(90deg, ${subjColor}4d, ${subjColor}b3);"></div>');
  replace('${pct>0 && status!==\'done\' ? `<span class="name-pct">${pct}%</span>` : \'\'}','<span class="name-pct">${pct>0 && status!==\'done\' ? pct+\'%\' : \'\'}</span>');
  replace('      state.sessions[key].push(justLoggedSession);\n      saveState();','      state.sessions[key].push(justLoggedSession);\n      if(linkedTaskId && state.targets[linkedTaskId]) completeIfDue(state.targets[linkedTaskId],key,taskPercent(state.targets[linkedTaskId],key,false));\n      saveState();');
  replace('      }\n      await flushStateNow();\n      if(isToday)','      }\n      if(isToday) reconcileLoggedTasks();\n      await flushStateNow();\n      if(isToday)');
  replace("      setSyncStatus('ok');\n      render();\n    }, (err)=>{","      setSyncStatus('ok');\n      reconcileLoggedTasks();\n      render();\n    }, (err)=>{");
  section('  function startLiveUiTicker(){','  function stopLiveUiTicker(){',`
  function startLiveUiTicker(){
    if(liveUiTickHandle) return;
    let lastMinute = -1;
    liveUiTickHandle = setInterval(()=>{
      updateLinkedProgress();
      if(currentScreen!=='timer' || document.hidden) return;
      const minutes = Math.round(elapsedMs/6000)/10;
      const ghost = document.querySelector('.garland-row.live');
      if(ghost){
        ghost.querySelector('.garland-pill').style.height = Math.max(40,Math.min(220,Math.round(minutes*2.5)))+'px';
        ghost.querySelector('.g-dur-tag').textContent = fmtHM(minutes)+' ●';
      }
      if(Math.floor(minutes)!==lastMinute){ lastMinute=Math.floor(minutes); renderGoalCard(); }
    },1000);
  }
`);
  replace("    wrap.style.display = opening ? 'block' : 'none';","    wrap.style.display = opening ? 'block' : 'none';\n    if(opening) renderHistory(); else invalidateHistory();");
  replace("      currentScreen = btn.dataset.screen;","      if(currentScreen==='history' && btn.dataset.screen!=='history') invalidateHistory();\n      currentScreen = btn.dataset.screen;");
  section('  async function loadMoreHistoryDays(){',"  document.querySelector('main').addEventListener('scroll', ()=>{\n    if(currentScreen!=='history')",`
  let historyGeneration = 0;
  function historyVisible(){
    return currentScreen==='history' && document.getElementById('historyDetailWrap').style.display!=='none';
  }
  function invalidateHistory(){
    historyGeneration++; historyInitialized=false; historyLoading=false; historyDates=[];
    historyBadges.clear();
  }
  async function loadMoreHistoryDays(){
    if(!historyVisible() || !historyInitialized || historyLoading || historyDates.length>=HISTORY_MAX_DAYS) return;
    historyLoading=true;
    const generation=historyGeneration, offset=historyDates.length;
    const dates=Array.from({length:Math.min(HISTORY_BATCH,HISTORY_MAX_DAYS-offset)},(_,i)=>{
      const date=new Date(historyAnchor); date.setDate(date.getDate()-offset-i); return date;
    });
    try{
      const rows=await Promise.all(dates.map(renderHistoryDayBlock));
      if(generation!==historyGeneration || !historyVisible()) return;
      const page=document.createElement('div'); page.innerHTML=rows.join('');
      document.getElementById('historyList').appendChild(page);
      historyDates.push(...dates); attachCommentButtons(page);
    } finally{ if(generation===historyGeneration) historyLoading=false; }
  }
  async function resetHistoryFeed(anchorDate){
    invalidateHistory();
    if(!historyVisible()) return;
    historyInitialized=true; historyAnchor=new Date(anchorDate);
    document.getElementById('historyList').innerHTML='';
    await loadMoreHistoryDays();
  }
  async function renderHistory(){
    if(!historyVisible() || historyInitialized) return;
    const date=document.getElementById('historyDate').value || fmtDate(new Date());
    await resetHistoryFeed(new Date(date+'T00:00:00'));
  }
`);
  replace("    await loadUsersList();\n    await loadMyGroupIds();","    renderHeaderAvatar();\n    renderTaskPinLabel();\n    reconcileLoggedTasks();\n    render();\n    showApp();\n    hideLoadBlocker();\n    recordReady();\n    await Promise.all([loadUsersList(),loadMyGroupIds(),loadMyReads()]);");
  replace("    await subscribeActiveGroup();\n    await loadMyReads();","    await subscribeActiveGroup();");
  replace("    hideLoadBlocker();\n    if(snap.exists() && snap.data().value){","    if(snap.exists() && snap.data().value){");
  before("  function checkJoinLinkParam(){",`
  function recordReady(){
    performance.mark('studyboard-ready');
    if(document.documentElement.hasAttribute('data-demo') || new URLSearchParams(location.search).has('perf')){
      let metric=document.getElementById('boardReadyMetric');
      if(!metric){
        metric=document.createElement('output'); metric.id='boardReadyMetric';
        metric.style.cssText='position:fixed;bottom:calc(78px + env(safe-area-inset-bottom));right:8px;z-index:55;background:#153034;color:#fff;padding:4px 8px;border-radius:5px;font:12px system-ui;pointer-events:none';
        document.body.appendChild(metric);
      }
      metric.textContent=(document.documentElement.hasAttribute('data-demo')?'Demo data · ':'')+'Board ready in '+(performance.now()/1000).toFixed(2)+' s';
    }
  }
`);
  replace("    refreshAllFriendBoards();\n    if(friendBoardsPollHandle)", "    if(currentScreen==='live' && !document.hidden) refreshAllFriendBoards();\n    if(friendBoardsPollHandle)");
  replace("    for(const u of friends){ await fetchFriendBoard(u.id); }","    if(currentScreen!=='live' || document.hidden) return;\n    await Promise.all(friends.map(u=>fetchFriendBoard(u.id)));");
  replace("    for(const u of usersList){ liveCache[u.id] = await getLiveStatus(u.id); }","    if(currentScreen!=='live' || document.hidden) return;\n    await Promise.all(usersList.filter(u=>u.id!==me.id).map(async u=>{liveCache[u.id]=await getLiveStatus(u.id);}));");
  replace("    updateFriendTimerCard();\n    refreshBellBadge();","    updateFriendTimerCard();");
  before("  function startLiveTimers(){","  let bellWatch = null;");
  replace("    liveTickHandle = setInterval(()=>{ renderPeopleRow(); renderSnapRow(); updateFriendTimerCard(); renderGoalCard(); }, 1000);",`    bellWatch = onSnapshot(doc(db,'notifications',me.id), snap=>{
      const count=snap.exists() ? (snap.data().items||[]).filter(item=>!item.read).length : 0;
      const badge=document.getElementById('bellBadge');
      badge.style.display=count?'flex':'none'; badge.textContent=count>9?'9+':String(count);
    },err=>console.warn('Notification badge unavailable',err));
    liveTickHandle = setInterval(()=>{
      if(!document.hidden && currentScreen==='live') renderSnapRow();
    },15000);`);
  replace("  function stopLiveTimers(){","  function stopLiveTimers(){\n    if(bellWatch){ bellWatch(); bellWatch=null; }");
  replace("      document.getElementById('screen-'+currentScreen).classList.add('active');","      document.getElementById('screen-'+currentScreen).classList.add('active');\n      if(currentScreen==='live' && me){ refreshLiveStatuses(); refreshAllFriendBoards(); }");
  replace("      deriveUsersList();\n      renderGroupBar();","      deriveUsersList();\n      if(currentScreen==='live' && !document.hidden){ refreshLiveStatuses(); refreshAllFriendBoards(); }\n      renderGroupBar();");
  replace("    if(!me) return false;\n    return permits(me.id, otherId);","    if(!me || (otherId!==me.id && !friendCache[otherId])) return false;\n    return permits(me.id, otherId);");
  replace("    }catch(e){\n      friendCache[id] = {subjects:{},targets:{},plans:{},completion:{},sessions:{}};\n    }","    }catch(e){ delete friendCache[id]; }");
  replace('family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet">','family=JetBrains+Mono:wght@500;700&display=swap" rel="stylesheet" media="print" onload="this.media=\'all\'">');
  section('import {\n  getMessaging,','const firebaseConfig =','let foregroundPush = null;\n\n');
  replace(`    const supported = await messagingIsSupported();
    if(!supported) return { ok:false, reason:'unsupported' };
    const perm = await Notification.requestPermission();`, `    if(document.documentElement.hasAttribute('data-demo') || !('serviceWorker' in navigator)) return {ok:false,reason:'unsupported'};
    const perm = await Notification.requestPermission();`);
  replace("    if(!swRegistration) swRegistration = await navigator.serviceWorker.ready;",`    const {getMessaging,getToken,onMessage,isSupported} = await import('https://www.gstatic.com/firebasejs/12.16.0/firebase-messaging.js');
    if(!await isSupported()) return {ok:false,reason:'unsupported'};
    if(!swRegistration) swRegistration=await navigator.serviceWorker.register('./sw.js');
    await navigator.serviceWorker.ready;`);
  replace("    onMessage(messaging, (payload)=>{","    foregroundPush?.();\n    foregroundPush = onMessage(messaging, (payload)=>{");
  replace("  .wgoal-card.open .wgoal-expand{ max-height:500px; margin-top:12px; }","  .wgoal-card.open .wgoal-expand{ max-height:500px; overflow-y:auto; margin-top:12px; }");

  replace("        attempts++;\n        showLoadBlocker", "        attempts++;\n        if(attempts>=3 || ['permission-denied','unauthenticated'].includes(e.code)) throw e;\n        showLoadBlocker");
  replace("    showLoadBlocker('Loading your data…');","    showLoadBlocker('Loading your board…');");
  replace("  let booted = false;","  let booted = false;\n  let pendingBoot = null;\n  let pendingBootUid = null;");
  replace("  async function bootAsUser(user, opts){","  function bootAsUser(user, opts){\n    if(pendingBoot && pendingBootUid===user.uid) return pendingBoot;\n    if(pendingBootUid && pendingBootUid!==user.uid){ location.reload(); return Promise.resolve(); }\n    pendingBootUid = user.uid;\n    pendingBoot = loadUserBoard(user,opts).catch(err=>{ pendingBoot=null; throw err; });\n    return pendingBoot;\n  }\n  async function loadUserBoard(user, opts){");
  replace("      booted = false;\n      me = null;","      if(pendingBootUid){ location.reload(); return; }\n      booted = false;\n      me = null;");
  replace("        await bootAsUser(cred.user, { name });\n        try{ await sendEmailVerification(cred.user); }catch(e){}", "        try{ await updateProfile(cred.user,{displayName:name}); }catch(e){}\n        try{ await sendEmailVerification(cred.user); }catch(e){}\n        await bootAsUser(cred.user, { name });");
  return html;
}

const root=process.cwd(), bundle=__dirname;
const related=['vercel.json','scripts/build-studyboard.mjs','scripts/studyboard-demo.mjs','tests/studyboard-smoke.cjs'];
const original=fs.readFileSync(path.join(root,'index.html'),'utf8');
const current=original.replace(/\r\n/g,'\n');
const sw=fs.readFileSync(path.join(root,'sw.js'),'utf8');
const outputs=new Map();
const applied=current.includes('const sharedView = {date:null, rows:[], unsubscribe:null};');
if(!applied){
  const updated=updateStudyBoard(current);
  outputs.set('index.html',original.includes('\r\n') ? updated.replace(/\n/g,'\r\n') : updated);
}
const split='// ---------- Push notifications ----------';
if(sw.split(split).length!==2)throw Error('The service worker has changed. Review its notification handlers before applying.');
const newWorker=fs.readFileSync(path.join(bundle,'worker-prefix.txt'),'utf8')+'\n'+sw.slice(sw.indexOf(split));
if(!applied)outputs.set('sw.js',newWorker);
for(const name of related){
  const file=path.join(root,name), proposed=fs.readFileSync(path.join(bundle,name),'utf8');
  if(fs.existsSync(file) && fs.readFileSync(file,'utf8')!==proposed)throw Error('Existing file needs a manual merge: '+name);
  outputs.set(name,proposed);
}
if(applied && sw!==newWorker)throw Error('This release is only partly applied. Review sw.js.');
for(const [name,contents] of outputs){
  fs.mkdirSync(path.dirname(path.join(root,name)),{recursive:true});
  fs.writeFileSync(path.join(root,name),contents);
}
console.log(applied?'Performance update already present.':'Applied performance update.');
